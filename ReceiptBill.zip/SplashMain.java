/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gextonproject;

/**
 *
 * @author Mehak
 */
public class SplashMain {
    
    public static void main(String args[]) {
        SplashScreen1 splassh= new SplashScreen1();
        splassh.setVisible(true);
        
        try {
            
        for (int i=0; i<=100;i++) {
            Thread.sleep(35);
            
            splassh.progresslabel.setText(Integer.toString(i)+"%");
       splassh.progressbar.setValue(i);
       
       if (i==100){
           splassh.setVisible(false);
           
           
       }
      
       
        }

            }
   catch(Exception e){
       
       
   } 
          new Screen2().show();
}
}